import streamlit as st
import pandas as pd
import numpy as np
import joblib

st.set_page_config(page_title="Football Predictor", page_icon="⚽")

bundle = joblib.load("football_predictor_model.joblib")
model = bundle["model"]
team_history = bundle["team_history"]
feature_columns = bundle["feature_columns"]
teams = bundle["teams"]

st.title("⚽ Football Match Predictor")
st.write("Predict home wins, draws, and away wins using historical match data.")

home_team = st.selectbox("Select home team", teams)
away_options = [t for t in teams if t != home_team]
away_team = st.selectbox("Select away team", away_options)

def recent_form(team):
    recent = team_history.get(team, [])[-5:]

    if not recent:
        return [0, 0, 0, 0, 0]

    return [
        np.mean([x[0] for x in recent]),
        np.mean([x[1] for x in recent]),
        np.mean([x[2] for x in recent]),
        sum(x[0] == 3 for x in recent),
        sum(x[0] == 0 for x in recent)
    ]

if st.button("Predict Match", type="primary"):
    hf = recent_form(home_team)
    af = recent_form(away_team)

    row = pd.DataFrame([{
        "HomePoints": hf[0],
        "HomeScored": hf[1],
        "HomeConceded": hf[2],
        "HomeWins": hf[3],
        "HomeLosses": hf[4],
        "AwayPoints": af[0],
        "AwayScored": af[1],
        "AwayConceded": af[2],
        "AwayWins": af[3],
        "AwayLosses": af[4]
    }])[feature_columns]

    probabilities = model.predict_proba(row)[0]
    classes = model.named_steps[
        "randomforestclassifier"
    ].classes_

    labels = {"H": "Home win", "D": "Draw", "A": "Away win"}
    results = sorted(
        zip(classes, probabilities),
        key=lambda x: x[1],
        reverse=True
    )

    st.subheader(f"{home_team} vs {away_team}")
    st.success(f"Predicted outcome: {labels[results[0][0]]}")

    for outcome, probability in results:
        st.write(f"**{labels[outcome]}:** {probability:.1%}")
        st.progress(float(probability))

st.caption("Predictions are estimates, not guarantees. The model uses historical data.")
